# qtwAcademic 

### 2022.12.22

Accepted in CRAN

### 2022.12.21

Submitted to CRAN

### 2022.12.20
Basic functionalities of the package are included.
